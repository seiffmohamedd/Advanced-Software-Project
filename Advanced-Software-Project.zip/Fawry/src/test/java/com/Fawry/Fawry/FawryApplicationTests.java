package com.Fawry.Fawry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FawryApplicationTests {

	@Test
	void contextLoads() {
	}

}
