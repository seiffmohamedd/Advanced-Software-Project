package Discounts;

import Discounts.Discount;

public class Specific extends Discount {

}
