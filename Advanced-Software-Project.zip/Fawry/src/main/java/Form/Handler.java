package Form;

public class Handler {
    String Display (){
    	return "your inputs has been recorded successfully";
    }
}
