package Form;

public interface FormComponent {
    Handler H = new Handler();
    void display();
}
