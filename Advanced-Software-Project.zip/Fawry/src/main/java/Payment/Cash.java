package Payment;

import Services.Service;

public class Cash extends payment{

}
