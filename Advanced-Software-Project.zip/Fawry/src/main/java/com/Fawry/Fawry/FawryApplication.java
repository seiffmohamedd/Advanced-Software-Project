package com.Fawry.Fawry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FawryApplication {

	public static void main(String[] args) {
		SpringApplication.run(FawryApplication.class, args);
	}

}
