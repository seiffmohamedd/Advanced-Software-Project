package Services;

public interface observer {
    public void update();
}
